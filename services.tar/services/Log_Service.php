<?php
// You can add a check on the timestamp of the returned response of a vehicle information if the  
// current timestamp and the response timestamp have a difference greater than a threshold say 1 hour 
// then change its active state to 'no', and as soon as this difference becomes less than the threshold change it to 
// 'yes', this will give the dynamic active state say, if the GPS device gets off because of power and then we can log it into
// error log or even mail to someone and then on power on it will get an active state to "yes". 
require_once "connect_db.php";
require_once "config_eTrans.php";
//require_once "../application/models/Bus_data_db.php";
require_once "Bus_data_db.php";
$postFields["Entity"] = $entity_id;
$query3 = $connection->prepare("SELECT ".Bus_data_db::$BUS_DEVICE_CODE." FROM ".Bus_data_db::$TABLE);
$query3->execute();
$result = $query3->get_result();
$i = 0;
$vehicleList = array();
while($row = $result->fetch_assoc()){
	$vehicleList[$i]["veh"] = $row[Bus_data_db::$BUS_DEVICE_CODE];
	//$bustable[$i]["log_table"] = $row[Bus_data_db::$BUS_TABLE_NAME];
	$i++;
	}
$postFields["VehicleList"] = $vehicleList; 
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://mobileapps.ev5.in/RestService/service/TrackInfo",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_PROXY => '10.3.100.207:8080',
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => json_encode($postFields),
  CURLOPT_HTTPHEADER => array(
    "authorization: Basic SUlUa2dwOklJVGtncEAxMjM=",
    "cache-control: no-cache",
    "content-type: application/json"
  ),
));

$respons = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);
//$respons = '{"LastInfo" :[{"coord":[{"lat":"28.93508000","lon":"79.46685200"}],"dt":"2016-05-06 15:21:07","speed":"0","loc":[{"wp1":"ASHOK LEYLAND-RUDRAPUR - UT/8.70 Km","wp2":"TATA STEEL PROCESSING-PANTNAGAR - UT/8.71 Km"}],"dist":"92017464","veh":"sahilc","entity":"SAIZAR ENTERPRISE PVT. LTD."}]}';
if($err){
	logError("CURL Error at Logging bus Data ",$err);
	exit(0);
} 
else
{	//print_r($response);
	$response = json_decode($respons,true);
	//print_r($response);
	if(isset($response["message"]) && $response["message"] == "Data not found"){
		logError("Bus data logging error",$response["message"]);
		exit(0);
		}
	else{
		//echo "entered";
		//print_r($response);
		//echo count($response["LastInfo"]);
		if(count($response["LastInfo"]) !== count($vehicleList) ){
			logError("Response Error", "the vehicle list provided and vehicle list returned didn't match");
			}
		else{
			for($i = 0 ; $i < count($response["LastInfo"]) ; $i++){
				//~ //echo count($response["LastInfo"]);
				$query = $connection->prepare("SELECT ".Bus_data_db::$BUS_TABLE_NAME." FROM ".Bus_data_db::$TABLE." WHERE ".Bus_data_db::$BUS_DEVICE_CODE."= ?");
				$query->bind_param("s",$response["LastInfo"][$i]["veh"]);
				if(!$query->execute()){
					logError("MYSQLI Execution error of finding tables",$query->error);
					exit(0);
					}
				$result = $query->get_result();
				if($result->num_rows == 0){
					logError("Bus Logging Error","NO bus found in the database with the bus code ".$response["LastInfo"][$i]["veh"]);
					exit(0);		
					}
				else if($result->num_rows > 1){
					logError("Bus Logging Error","Multiple rows with bus code ".$response["LastInfo"][$i]["veh"].". Check The database.");
					exit(0);
					}
				else
				{
					 $row = $result->fetch_assoc();
					 $bus_log_tabel = $row[Bus_data_db::$BUS_TABLE_NAME];
					 //echo $bus_log_tabel;
					 //echo "INSERT INTO ".$bustable[$i]["log_table"]." (lat,lon,time_stamp) VALUES (?,?,?)";
					 $query2 = $connection->prepare("INSERT INTO ".$bus_log_tabel." (lat,lon,time_stamp) VALUES (?,?,?)");
					 $query2->bind_param("sss",$response["LastInfo"][$i]["coord"][0]["lat"],$response["LastInfo"][$i]["coord"][0]["lon"],$response["LastInfo"][$i]["dt"]);
					 if(!$query2->execute()){
						logError("MYSQLI Execution error of logging coords",$query2->error);
						exit(0);
						}
					else{
						//echo "success";
						}
					}
				}
			}
		}
}
?>
