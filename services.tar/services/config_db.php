<?php
$db_name = "bus_tracking";
$db_password = "";
$db_username = "root";
$db_host = "localhost";
?>
