<?php
$entity_id = "12581";
$user_id = "IITkgp";
$password = "IITkgp@123";
?>
