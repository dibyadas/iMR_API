<?php
function logError($errorType,$errorMsg){
$error_file = fopen("error_log","a") or die("unable to open file");
date_default_timezone_set("Asia/Kolkata");
$timeStamp = date("D M j G:i:s T Y");
$input = $timeStamp." | ".$errorType." : ".$errorMsg."\n";
fwrite($error_file, $input);
fclose($error_file);
}
?>
