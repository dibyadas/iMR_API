<?php
require_once "connect_db.php";
require_once "../application/models/Bus_data_db.php";
$query3 = $connection->prepare("SELECT ".Bus_data_db::$BUS_TABLE_NAME.",".Bus_data_db::$BUS_DEVICE_CODE." FROM ".Bus_data_db::$TABLE);
$query3->execute();
$result = $query3->get_result();
$i = 0;
while($row = $result->fetch_assoc()){
	$vehicleList[$i]["table_name"] = $row[Bus_data_db::$BUS_TABLE_NAME];
	$vehicleList[$i]["device_code"] = $row[Bus_data_db::$BUS_DEVICE_CODE];
	$i++;
	}
//print_r($vehicleList);
date_default_timezone_set("Asia/Kolkata");
$timeStamp = date("M j Y");
for($i = 0 ; $i < count($vehicleList) ; $i++){
	//echo "SELECT * INTO OUTFILE 'files".$i.".txt' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' LINES TERMINATED BY '\n' FROM ".$vehicleList[$i]."";
	//echo "</br>";
	$query2 = $connection->prepare("SELECT * INTO OUTFILE 'Log_".$timeStamp."_".$vehicleList[$i]["device_code"].".txt' FIELDS TERMINATED BY ',' ENCLOSED BY '\"' LINES TERMINATED BY '\n' FROM ".$vehicleList[$i]["table_name"]."");
	$query2->execute();
	$query4 = $connection->prepare("TRUNCATE ".$vehicleList[$i]["table_name"]);
	$query4->execute();
	}
	
?>
