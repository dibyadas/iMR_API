<?php
include("config_db.php");
require_once("error_logging.php");
$connection = new mysqli($db_host,$db_username,$db_password,$db_name);
if($connection->connect_error) {
	logError("DB Connection Error",$connection->connect_error);
}
?>
