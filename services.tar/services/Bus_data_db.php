<?php 
	final class Bus_data_db{
		public static $TABLE = "bus_data";
		public static $BUS_NAME = "bus_name";
		public static $BUS_NUMBER = "bus_number";
		public static $BUS_CODE = "bus_code";
		public static $BUS_ROUTE = "bus_route";
		public static $BUS_TABLE_NAME = "bus_table_name";
		public static $BUS_DEVICE_CODE = "GPS_device_code";
		public static $BUS_ACTIVE = "active";
		}
?>
